"use strict";
const bannerToggle = document.querySelector("#banner-toggle");
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.bannerEnabled && bannerToggle) {
        bannerToggle.checked = changes.bannerEnabled.newValue === true;
    }
    if (area === "local" && changes.organizationProtection)
        void renderBlockedSites();
});
bannerToggle?.addEventListener("change", async () => {
    try {
        await chrome.runtime.sendMessage({
            type: "setBanner",
            enabled: bannerToggle.checked,
        });
        setStatus(bannerToggle.checked
            ? "Floating notifications enabled."
            : "Floating notifications hidden.");
    }
    catch {
        setStatus("Could not save notification setting.");
    }
});
const monitoringToggle = document.querySelector("#monitoring-toggle");
const refreshButton = document.querySelector("#refresh-button");
const historyButton = document.querySelector("#history-button");
const statusElement = document.querySelector("#status");
const latestElement = document.querySelector("#latest");
monitoringToggle?.addEventListener("change", async () => {
    try {
        const response = await chrome.runtime.sendMessage({
            type: "setMonitoring",
            enabled: monitoringToggle.checked,
        });
        setStatus(response?.monitoringEnabled
            ? "Monitoring is active."
            : "Monitoring is paused.");
    }
    catch (error) {
        console.error("Could not save monitoring state", error);
        setStatus("Could not save monitoring state. Try again.");
    }
});
historyButton?.addEventListener("click", async () => {
    setStatus("Opening CyberGuard dashboard...");
    try {
        await chrome.runtime.sendMessage({ type: "openDashboard" });
        setStatus("Dashboard opened. Sign in to enable history saving.");
    }
    catch (error) {
        console.error("Could not open CyberGuard dashboard", error);
        setStatus("Could not open the dashboard.");
    }
});
refreshButton?.addEventListener("click", () => {
    void refreshActivity();
});
void loadState();
async function loadState() {
    try {
        const state = await chrome.runtime.sendMessage({ type: "getState" });
        monitoringToggle.checked = state.monitoringEnabled;
        bannerToggle.checked = state.bannerEnabled;
        if (state.historyEnabled && state.authenticated) {
            historyButton.textContent = "History saving is active";
            historyButton.disabled = true;
        }
        else {
            historyButton.textContent = "Connect dashboard to save history";
            historyButton.disabled = false;
        }
        if (state.activity.length) {
            await renderActivity(state.activity);
            return;
        }
        await refreshActivity();
    }
    catch (error) {
        console.error("Could not load extension state", error);
        setStatus("Could not connect to the monitor. Reload the extension and try again.");
        latestElement.textContent =
            "The extension background worker did not respond.";
    }
}
async function refreshActivity() {
    setStatus("Checking the current page...");
    latestElement.textContent = "Running live URL check...";
    refreshButton?.setAttribute("disabled", "true");
    try {
        const refreshedState = await chrome.runtime.sendMessage({
            type: "refresh",
        });
        if (refreshedState.activity.length) {
            await renderActivity(refreshedState.activity);
            return;
        }
        setStatus("No websites have been recorded yet.");
        latestElement.textContent =
            "Open an http or https website to start monitoring.";
    }
    catch (error) {
        console.error("Popup live check failed", error);
        setStatus("Could not reach the CyberGuard backend.");
        latestElement.textContent =
            "Check your internet connection and try again. The hosted service may be starting up.";
    }
    finally {
        refreshButton?.removeAttribute("disabled");
    }
}
async function renderActivity(activity) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    activity = activity.filter((item) => item.url === tabs[0]?.url);
    if (!activity.length) {
        setStatus("No websites have been recorded yet.");
        latestElement.textContent = "Browse to a website to create live activity.";
        return;
    }
    const [latest] = activity;
    setStatus("Current website checked.");
    latestElement.innerHTML = `
		<span class="risk risk-${latest.riskLevel.toLowerCase().replaceAll("_", "-")}">${latest.riskLevel === "SUSPICIOUS" && latest.pageWarning ? "Suspicious page" : formatRisk(latest.riskLevel)}</span>
		<strong>${escapeHtml(latest.domain)}</strong>
		<p>${escapeHtml(latest.explanation?.[0] ?? "No explanation available.")}</p>
	`;
}
function formatRisk(riskLevel) {
    return riskLevel.replaceAll("_", " ");
}
function setStatus(message) {
    statusElement.textContent = message;
}
function escapeHtml(value) {
    const element = document.createElement("span");
    element.textContent = value;
    return element.innerHTML;
}
const blockButton = document.querySelector("#block-site");
let rulesRefresh = null;
let rulesRefreshAgain = false;
function renderBlockedSites() {
    if (rulesRefresh) {
        rulesRefreshAgain = true;
        return rulesRefresh;
    }
    rulesRefresh = (async () => {
        do {
            rulesRefreshAgain = false;
            await renderBlockedSitesOnce();
        } while (rulesRefreshAgain);
    })().finally(() => {
        rulesRefresh = null;
    });
    return rulesRefresh;
}
async function renderBlockedSitesOnce() {
    try {
        const state = await chrome.runtime.sendMessage({
            type: "getBlockedSites",
        });
        if (state.error)
            throw new Error(state.error);
        const tabs = await chrome.tabs.query({
            active: true,
            currentWindow: true,
        });
        let domain = "";
        try {
            const url = new URL(tabs[0]?.url ?? "");
            if (["http:", "https:"].includes(url.protocol))
                domain = url.hostname;
        }
        catch {
            /* Restricted page. */
        }
        const organizationDomains = state.organizationDomains ?? [];
        const organizationRules = state.organizationRules ??
            organizationDomains.map((domain) => ({
                domain,
                action: "block",
                accessExpiresAt: undefined,
            }));
        const managed = organizationRules.find((rule) => rule.action === "block" &&
            !rule.accessExpiresAt &&
            (domain === rule.domain || domain.endsWith(`.${rule.domain}`)));
        const covering = state.domains.find((host) => domain === host || domain.endsWith(`.${host}`));
        document.querySelector("#blocking-domain").textContent =
            domain || "Open a website to block it";
        document.querySelector("#blocked-count").textContent = String(state.domains.length + organizationDomains.length);
        blockButton.classList.toggle("is-blocked", Boolean(covering || managed));
        blockButton.disabled = !domain || Boolean(managed);
        blockButton.textContent = managed
            ? "Blocked by organization"
            : covering
                ? "Unblock"
                : "Block website";
        blockButton.setAttribute("aria-label", managed
            ? `Blocked by organization: ${managed.domain}`
            : covering
                ? `Unblock ${covering}`
                : `Block ${domain || "website"}`);
        blockButton.title = managed
            ? "Managed in Team Security by your organization"
            : covering
                ? `Unblock ${covering} and its subdomains`
                : `Block ${domain || "this website"} and its subdomains`;
        blockButton.onclick = () => {
            void changeBlock(covering ?? domain, !covering);
        };
        const list = document.querySelector("#blocked-sites");
        list.replaceChildren();
        for (const host of state.domains) {
            const row = document.createElement("li");
            const name = document.createElement("span");
            name.textContent = `${host} · Personal · Blocked`;
            const button = document.createElement("button");
            button.textContent = "Unblock";
            button.type = "button";
            button.setAttribute("aria-label", `Unblock ${host}`);
            button.onclick = () => {
                void changeBlock(host, false);
            };
            row.append(name, button);
            list.append(row);
        }
        for (const rule of organizationRules) {
            const row = document.createElement("li");
            row.textContent = `${rule.domain} · Organization · ${rule.action === "warn" ? "Warning" : rule.accessExpiresAt ? `Temporary access until ${new Date(rule.accessExpiresAt).toLocaleString()}` : "Blocked"}`;
            list.append(row);
        }
        if (!state.domains.length && !organizationDomains.length)
            list.textContent = "No website rules.";
    }
    catch {
        blockButton.disabled = true;
        setStatus("Could not load website rules. Reload the extension.");
    }
}
async function changeBlock(domain, blocked) {
    blockButton.disabled = true;
    try {
        const response = await chrome.runtime.sendMessage({
            type: "setSiteBlocked",
            domain,
            blocked,
        });
        if (!response.ok)
            throw new Error(response.error);
        await renderBlockedSites();
        setStatus(blocked
            ? `${domain} blocked for future visits.`
            : `${domain} unblocked. Reload its tab to visit it.`);
    }
    catch {
        setStatus("Could not change blocking. Try again.");
        await renderBlockedSites();
    }
}
void renderBlockedSites();
