export function matchesDomain(host, domain) {
    return host === domain || host.endsWith(`.${domain}`);
}
export function activeApproval(domain, approvals, now = Date.now()) {
    return approvals.find((approval) => approval.domain === domain && Date.parse(approval.expires_at) > now);
}
export function evaluateNavigation(input, policies, approvals, now = Date.now()) {
    const url = new URL(input);
    if (!["http:", "https:"].includes(url.protocol) ||
        url.username ||
        url.password)
        throw new Error("Only HTTP/HTTPS websites without embedded credentials can be opened.");
    const matching = policies.filter((policy) => matchesDomain(url.hostname, policy.domain));
    if (!matching.length)
        throw new Error("No matching organization rule. Open the website again.");
    const blocks = matching.filter((policy) => policy.action === "block");
    const grants = blocks.map((policy) => activeApproval(policy.domain, approvals, now));
    return {
        url: url.href,
        policies: matching,
        allowed: grants.every(Boolean),
        expiresAt: grants.length && grants.every(Boolean)
            ? new Date(Math.min(...grants.map((grant) => Date.parse(grant.expires_at)))).toISOString()
            : undefined,
    };
}
